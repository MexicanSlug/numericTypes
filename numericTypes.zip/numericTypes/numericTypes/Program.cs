﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Please enter the length of the rectangle:");
        string lengthInput = Console.ReadLine();
        
        double length;
        while (!double.TryParse(lengthInput, out length))
        {
            Console.WriteLine("Invalid input. Please enter a numeric value for the length:");
            lengthInput = Console.ReadLine();
        }

        Console.WriteLine("Please enter the width of the rectangle:");
        string widthInput = Console.ReadLine();
    
        double width;
        while (!double.TryParse(widthInput, out width))
        {
            Console.WriteLine("Invalid input. Please enter a numeric value for the width:");
            widthInput = Console.ReadLine();
        }

        double area = length * width;

        Console.WriteLine("The area of the rectangle with length " + length + " and width " + width + " is: " + area);
    }
}

